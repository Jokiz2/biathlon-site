import Link from 'next/link'
export default function Header(){
  return (
    <header className="bg-white/80 backdrop-blur sticky top-0 z-40 shadow-sm">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-sky-600 flex items-center justify-center text-white font-bold">B</div>
          <div><div className="text-lg font-semibold">Общая Федерация Биатлона</div><div className="text-sm text-slate-500">Развиваем биатлон в регионе</div></div>
        </div>
        <nav className="flex items-center gap-3">
          <Link href="/" className="px-3 py-2 rounded-md text-sm font-medium">Главная</Link>
          <Link href="/about" className="px-3 py-2 rounded-md text-sm font-medium">О нас</Link>
          <Link href="/events" className="px-3 py-2 rounded-md text-sm font-medium">События</Link>
          <Link href="/team" className="px-3 py-2 rounded-md text-sm font-medium">Команда</Link>
          <Link href="/membership" className="px-3 py-2 rounded-md text-sm font-medium">Членство</Link>
          <Link href="/contact" className="px-3 py-2 rounded-md text-sm font-medium">Контакты</Link>
          <Link href="/donate" className="ml-3 px-4 py-2 rounded-md bg-amber-500 text-white font-semibold">Поддержать</Link>
        </nav>
      </div>
    </header>
  )
}
