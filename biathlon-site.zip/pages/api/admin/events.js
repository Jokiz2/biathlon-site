import fs from 'fs'
import path from 'path'
export default function handler(req,res){
  const file = path.join(process.cwd(),'data','events.json')
  if(req.method==='GET'){
    try{ const data = JSON.parse(fs.readFileSync(file)); return res.status(200).json(data) }catch(e){ return res.status(200).json([]) }
  }
  if(req.method==='POST'){
    const ev = req.body
    let list = []
    try{ list = JSON.parse(fs.readFileSync(file)) }catch(e){ list = [] }
    ev.id = Date.now()
    list.push(ev)
    fs.writeFileSync(file,JSON.stringify(list,null,2))
    return res.status(201).json(ev)
  }
  if(req.method==='DELETE'){
    const {id} = req.query
    let list=[]
    try{ list = JSON.parse(fs.readFileSync(file)) }catch(e){ list = [] }
    list = list.filter(x=>String(x.id)!==String(id))
    fs.writeFileSync(file,JSON.stringify(list,null,2))
    return res.status(200).json({ok:true})
  }
  return res.status(405).end()
}
