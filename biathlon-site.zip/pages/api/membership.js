import fs from 'fs'
import path from 'path'
export default function handler(req,res){
  if(req.method!=='POST') return res.status(405).end()
  const data = req.body
  const listPath = path.join(process.cwd(),'data','applications.json')
  let apps = []
  try{ apps = JSON.parse(fs.readFileSync(listPath)) }catch(e){ apps = [] }
  apps.push({...data, receivedAt: new Date().toISOString()})
  fs.writeFileSync(listPath,JSON.stringify(apps,null,2))
  return res.status(200).json({ok:true})
}
