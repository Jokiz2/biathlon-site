'use client'
import {useEffect,useState} from 'react'
export default function Admin(){
  const [events,setEvents]=useState([]); const [form,setForm]=useState({title:'',date:'',place:'',desc:''})
  async function load(){ const res=await fetch('/api/admin/events'); setEvents(await res.json()) }
  useEffect(()=>{ load() },[])
  async function add(e){ e.preventDefault(); await fetch('/api/admin/events',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(form)}); setForm({title:'',date:'',place:'',desc:''}); await load() }
  async function remove(id){ await fetch('/api/admin/events?id='+id,{method:'DELETE'}); await load() }
  return (<section><h2 className="text-2xl font-semibold">Admin — Events</h2>
    <form onSubmit={add} className="mt-4 bg-white p-4 rounded shadow-sm space-y-2">
      <input required value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="Title" className="w-full border px-2 py-1"/>
      <input value={form.date} onChange={e=>setForm({...form,date:e.target.value})} placeholder="Date" className="w-full border px-2 py-1"/>
      <input value={form.place} onChange={e=>setForm({...form,place:e.target.value})} placeholder="Place" className="w-full border px-2 py-1"/>
      <textarea value={form.desc} onChange={e=>setForm({...form,desc:e.target.value})} placeholder="Description" className="w-full border px-2 py-1"></textarea>
      <div><button className="px-3 py-1 bg-sky-600 text-white rounded">Add event</button></div>
    </form>
    <div className="mt-4 space-y-2">
      {events.map(ev=> (<div key={ev.id} className="p-3 bg-white rounded shadow-sm flex justify-between"><div><div className="font-semibold">{ev.title}</div><div className="text-sm text-slate-500">{ev.date} — {ev.place}</div></div><button onClick={()=>remove(ev.id)} className="text-red-600">Delete</button></div>))}
    </div>
  </section>)
}
