import Link from 'next/link'
export default function Home() {
  return (
    <section className="grid md:grid-cols-2 gap-8 items-center">
      <div>
        <h1 className="text-4xl font-extrabold">Общественная Федерация Биатлона</h1>
        <p className="mt-4 text-lg text-slate-600">Тренировки, соревнования и поддержка молодёжи. Присоединяйтесь!</p>
        <div className="mt-6 flex gap-3">
          <Link href="/membership" className="px-5 py-3 rounded-md bg-sky-600 text-white">Стать членом</Link>
          <Link href="/events" className="px-5 py-3 rounded-md border">Смотреть события</Link>
        </div>
      </div>
      <div className="rounded-2xl overflow-hidden shadow-lg bg-gradient-to-tr from-sky-50 to-white p-6">
        <img alt="biathlon" src="/images/biathlon-hero.jpg" className="w-full h-72 object-cover rounded-lg" />
      </div>
    </section>
  )
}
