import TeamCard from '../../components/TeamCard'
import fs from 'fs'
import path from 'path'
export default function Team(){
  const dataPath = path.join(process.cwd(),'data','team.json')
  let team = []
  try { team = JSON.parse(fs.readFileSync(dataPath)) } catch(e){ team = [] }
  return (<section>
    <h2 className="text-2xl font-semibold">Наша команда</h2>
    <div className="mt-6 grid md:grid-cols-3 gap-4">
      {team.map(m=> <TeamCard key={m.id} member={m} />)}
    </div>
  </section>)
}
