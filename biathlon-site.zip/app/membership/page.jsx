export default function Membership(){
  return (<section className="max-w-2xl">
    <h2 className="text-2xl font-semibold">Членство</h2>
    <p className="mt-2 text-slate-600">Присоединяйтесь к нашему движению.</p>
    <form className="mt-6 space-y-4 bg-white p-6 rounded-lg shadow-sm" onSubmit={e=>{e.preventDefault();alert('Заявка отправлена (имитация)')}}>
      <div><label className="block text-sm font-medium">ФИО</label><input required className="mt-1 block w-full rounded-md border px-3 py-2" /></div>
      <div><label className="block text-sm font-medium">Email</label><input type="email" required className="mt-1 block w-full rounded-md border px-3 py-2" /></div>
      <div className="flex items-center gap-3"><button type="submit" className="px-4 py-2 rounded-md bg-sky-600 text-white">Отправить заявку</button></div>
    </form>
  </section>)
}
