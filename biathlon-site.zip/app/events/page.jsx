import EventCard from '../../components/EventCard'
import fs from 'fs'
import path from 'path'
export default async function Events(){ 
  const dataPath = path.join(process.cwd(),'data','events.json')
  let events = []
  try { events = JSON.parse(fs.readFileSync(dataPath)) } catch(e){ events = [] }
  return (<section>
    <div className="flex items-center justify-between">
      <h2 className="text-2xl font-semibold">Ближайшие события</h2>
    </div>
    <div className="mt-6 grid md:grid-cols-2 gap-4">
      {events.map(e=> <EventCard key={e.id} e={e} />)}
    </div>
  </section>)
}
