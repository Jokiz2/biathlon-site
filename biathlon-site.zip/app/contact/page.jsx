'use client'
import {useState} from 'react'
export default function Contact(){
  const [state,setState]=useState({name:'',email:'',message:''})
  const send=async e=>{ e.preventDefault(); try{ await fetch('/api/contact',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(state)}); alert('Отправлено') }catch{alert('Ошибка')}}
  return (<section className="grid md:grid-cols-2 gap-6">
    <div><h2 className="text-2xl font-semibold">Контакты</h2><p className="mt-2 text-slate-600">Телефон: +7 (495) 123-45-67</p></div>
    <div><h3 className="text-lg font-medium">Написать нам</h3>
      <form className="mt-4 space-y-3 bg-white p-4 rounded-lg shadow-sm" onSubmit={send}>
        <input value={state.name} onChange={e=>setState({...state,name:e.target.value})} placeholder="Ваше имя" className="w-full rounded-md border px-3 py-2" />
        <input value={state.email} onChange={e=>setState({...state,email:e.target.value})} placeholder="Email" className="w-full rounded-md border px-3 py-2" />
        <textarea value={state.message} onChange={e=>setState({...state,message:e.target.value})} placeholder="Текст сообщения" rows={4} className="w-full rounded-md border px-3 py-2" />
        <div className="flex justify-end"><button type="submit" className="px-4 py-2 rounded-md bg-sky-600 text-white">Отправить</button></div>
      </form>
    </div>
  </section>)
}
