import './globals.css'
import Header from '../components/Header'
import Footer from '../components/Footer'
export const metadata = { title: 'Общественная Федерация Биатлона' }
export default function RootLayout({ children }) {
  return (
    <html lang="ru">
      <body className="bg-slate-50 text-slate-900">
        <Header />
        <main className="max-w-6xl mx-auto px-6 py-12">{children}</main>
        <Footer />
      </body>
    </html>
  )
}
