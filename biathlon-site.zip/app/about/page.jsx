export default function About(){
  return (<section className="prose max-w-none">
    <h2>О нашей организации</h2>
    <p>Мы развиваем биатлон в регионе: тренировки, соревнования, детские программы.</p>
  </section>)
}
