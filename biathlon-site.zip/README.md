# Biathlon Organization — Next.js Site
Run locally:
1. cp .env.example .env
2. npm install
3. npm run dev
